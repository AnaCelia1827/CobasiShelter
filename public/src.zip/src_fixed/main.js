import { jogoAlimentacao } from "./cenas/jogoAlimentacao.js";
import { cenaInicial } from "./cenas/cenaInicial.js";
import { cenaBanho } from "./cenas/cenaBanho.js";
import { cenaConfiguracoes } from "./cenas/cenaConfiguracoes.js";
import { cenaComida } from "./cenas/cenaComida.js";
import { cenaTutorial } from "./cenas/cenaTutorial.js";
import { cenaPrincipal } from "./cenas/cenaPrincipal.js";
import { jogoLazer } from "./cenas/jogoLazer.js";
import {cenaLazer} from "./cenas/cenaLazer.js";
import { HUD } from "./componentes/HUD.js";
import { cenaCuidado } from "./cenas/cenaCuidado.js";
import { ficha } from "./componentes/ficha.js";
import { cenaCarregamento } from "./cenas/cenaCarregamento.js";
import {cenaVeterinario } from "./cenas/cenaVeterinario.js";
import {cenaRacaoStandart } from "./cenas/cenaRacaoStandart.js";
import {cenaRacaoSuperPremium } from "./cenas/cenaRacaoSuperPremium.js";


// Objeto global para armazenar estados do jogo
export let gameState = {
    barras: {
        comida: 9,
        lazer: 9,
        limpeza: 9,
        saude: 9
    },
    cobasiCoins: 20,
    recompensas: {
        banho: false
    },
    pets: {
        cachorroCaramelo: true,
        cachorroHeroi: false
    },
    pulga: true,
    trocar: false
 
};

// ─── RESOLUÇÃO FIXA DO JOGO ───────────────────────────────────────────────────
// O jogo sempre roda em 480×854 (proporção 9:16, padrão mobile portrait).
// O Phaser escala o canvas para caber na tela mantendo a proporção e centralizando.
// Nenhum código de cena precisa se preocupar com window.innerWidth ou resize.
const GAME_WIDTH  = 800;
const GAME_HEIGHT = 600;

// Configuração principal do Phaser
const config = {
    type: Phaser.AUTO,

    width:  GAME_WIDTH,
    height: GAME_HEIGHT,

    scale: {
        mode:       Phaser.Scale.FIT,        // Escala para caber na tela, mantendo proporção
        autoCenter: Phaser.Scale.CENTER_BOTH // Centraliza horizontal e verticalmente
    },

    audio: {
        disableWebAudio: false,
        noAudio: false
    },

    physics: {
        default: "arcade",
        arcade: {
            gravity: { y: 0 },
            debug: false
        }
    },

    scene: [
        cenaCarregamento,
        cenaInicial,
        cenaTutorial,
        jogoAlimentacao,
        cenaConfiguracoes,
        cenaBanho,
        cenaComida,
        cenaCuidado,
        cenaVeterinario,
        cenaPrincipal,
        HUD,
        jogoLazer,
        cenaRacaoStandart,
        cenaLazer,
        ficha,
        cenaRacaoSuperPremium
    ]
};

// Inicializa o jogo
const game = new Phaser.Game(config);
